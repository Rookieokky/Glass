package com.example.glance;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import com.google.android.glass.app.Card;
import com.google.android.glass.widget.CardScrollAdapter;
import com.google.android.glass.widget.CardScrollView;


////////////////////////////////////Picture////////////////////////////////////
public class Picture extends Activity {
	
	public static final int MEDIA_TYPE_IMAGE = 1;
	public static final String UPLOAD_OCR = "http://ec2-54-186-34-253.us-west-2.compute.amazonaws.com/upload_ocr.php"; //to upload the image
	public static final String DICTIONARY = "http://ec2-54-186-34-253.us-west-2.compute.amazonaws.com/dictionary.php"; //meaning of the word
	public static final String WORD_IMAGE = "http://ec2-54-186-34-253.us-west-2.compute.amazonaws.com/word_image.php"; //to get the image
	
    // "http://ec2-54-186-34-253.us-west-2.compute.amazonaws.com/Sprintz.html" 
	
	public static List<Card> mCards;
	
	List<String>words = new ArrayList<String>();
	List<String>meanings = new ArrayList<String>();
	private String current;
	
	private Uri fileUri;
	private CardScrollView mCardScrollView;
	
	
	@Override
	//*****************************onCreate()*****************************
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_picture);
	}
	
	@Override
	//*****************************onKeyDown()*****************************
    public boolean onKeyDown(int keycode, KeyEvent event) 
	{
        if (keycode == KeyEvent.KEYCODE_DPAD_CENTER) 
        { takePicture(); return true; }
        return false;
    }
	
	//*****************************takePicture()*****************************
	private void takePicture() 
	{
	    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	    File file = new File(Environment.getExternalStorageDirectory(),"test.jpg");
	    fileUri = Uri.fromFile(file);
	    intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
	    startActivityForResult(intent, MEDIA_TYPE_IMAGE);
	    
	    //getWords();
	    words.add("banana");
	    words.add("road");
	    getMeanings();
	    
	}
	
	//*****************************initiate()*****************************
	private void initiate()
	{	
		
		createCards();
		
		mCardScrollView = new CardScrollView(this);
        CardScroll cs = new CardScroll();
        mCardScrollView.setAdapter(cs);
        mCardScrollView.activate();
        setContentView(mCardScrollView);
	}

	//*****************************createCards()*****************************
	private void createCards()
	{
		mCards = new ArrayList<Card>();
		Card card;
		
		for(int i=0; i<words.size(); i++)
		{
			current = words.get(i);
			card = new Card(getApplicationContext());
			card.setText(words.get(i));
			card.setFootnote(meanings.get(i));
			mCards.add(card);
		}
	}
	
	//*****************************getWords()*****************************
	//sends image receives string array 
	public void getWords()
	{
		HttpClient httpclient = new DefaultHttpClient();
	    HttpPost httppost = new HttpPost(UPLOAD_OCR);
	
	    try 
	    {
	        // Add your data
	        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	        nameValuePairs.add(new BasicNameValuePair("image", ""));
	        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	
	        HttpResponse res = httpclient.execute(httppost);
	        
	        InputStream in = res.getEntity().getContent();
	        BufferedReader bfrd = new BufferedReader(new InputStreamReader(in),1024);
	        String line;
	        while((line = bfrd.readLine()) != null)
	        { words.add(line.toString()); }
	        
	    } catch (ClientProtocolException e) {
	    	
	        // TODO Auto-generated catch block
	    } catch (IOException e) {
	        // TODO Auto-generated catch block
	    }
	}

	//*****************************getMeanings()*****************************
	//sends word receives meaning
	public void getMeanings() 
	{
		LongOperation op = new LongOperation() {
			protected void onPostExecute(java.util.List<String> result) {
				Picture.this.meanings = result;
				initiate();
			};
		};
		
		op.execute(words);
	} 


	private class LongOperation extends AsyncTask<List<String>, Void, List<String>>
	{

		@Override
		protected List<String> doInBackground(List<String>... arg0) {
			List<String> meanings2 = new ArrayList<String>();
			for(String word : arg0[0]){
				try 
		        {
		    		
		    		HttpClient httpclient = new DefaultHttpClient();
		            HttpPost httppost = new HttpPost(DICTIONARY);
	
		            try 
		            {
		                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		                nameValuePairs.add(new BasicNameValuePair("word", word));
		                System.out.println("RUUUUUUUUUUUUUUUUUN");
		                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	
		                // Execute HTTP Post Request
		                HttpResponse res = httpclient.execute(httppost);
		                InputStream is = res.getEntity().getContent();
		                System.out.println("RESPONSEEEEE  "+is);
		                
		                meanings2.add(is.toString());
	
		            } catch (ClientProtocolException e) {
		                // TODO Auto-generated catch block
		            } catch (IOException e) {
		                System.out.println(e.getMessage());
		                meanings2.add("abc");
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
			}
			return meanings2;
		}
		
	}
	
	
	////////////////////////////////////CardScroll////////////////////////////////////
	private class CardScroll extends CardScrollAdapter {

		
		@Override
        public int findIdPosition(Object id) {
            return -1;
        }

        @Override
        public int findItemPosition(Object item) {
            return mCards.indexOf(item);
        }

        @Override
        public int getCount() {
            return mCards.size();
        }

        @Override
        public Object getItem(int position) {
            return mCards.get(position);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return mCards.get(position).toView();
        }
    }
}
